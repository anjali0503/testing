import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviwer-menu',
  templateUrl: './interviwer-menu.component.html',
  styleUrls: ['./interviwer-menu.component.css']
})
export class InterviwerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
