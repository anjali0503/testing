import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tl-menu',
  templateUrl: './tl-menu.component.html',
  styleUrls: ['./tl-menu.component.css']
})
export class TlMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
}
