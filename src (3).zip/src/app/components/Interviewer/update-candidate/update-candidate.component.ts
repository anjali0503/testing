import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { Interviewer } from 'src/app/domain/interviwer';
import { ApplicantService } from 'src/app/services/applicant.service';
import { InterviewerService } from 'src/app/services/interviewer.service';

@Component({
  selector: 'app-update-candidate',
  templateUrl: './update-candidate.component.html',
  styleUrls: ['./update-candidate.component.css']
})
export class UpdateCandidateComponent implements OnInit {
 interviewerId:number=0;
 Interviewer:Interviewer=new Interviewer();
 submitted:boolean=false;
 result:boolean=false;
 applicant:ApplicantDetails=new ApplicantDetails();
  constructor(private interviewerService:InterviewerService,
    private activateRoute :ActivatedRoute,
    private router:Router,
    private applicantService: ApplicantService) { }

  ngOnInit(): void {
    console.log("in update result component");
    this.interviewerId=this.activateRoute.snapshot.params['interviewId']
    this.interviewerService.getSinglelApplicant(this.interviewerId).subscribe(
      data=>{
        this.Interviewer=data;
        console.log(this.Interviewer);
        
    });
    
  }

  updateResult(){
      this.interviewerService.updateResult(this.Interviewer).subscribe(
        data=>{
          this.result=data;
          console.log(this.result);
          this.submitted=true;
          this.updateApplicantStatus(this.applicant);
          
        }
      );
  }

  updateApplicantStatus(applicant:ApplicantDetails){
    console.log("in updateRequiredCount()");
    this.applicantService.updateApplicantStatusS(applicant).subscribe(
      data=>{
        console.log("in update");
        this.applicant=data;
        console.log( this.applicant);
        
        
      }
    );
    
  }

  backtohome(){
    this.router.navigate(["HomeInterviewerpage"]);
  }

}
