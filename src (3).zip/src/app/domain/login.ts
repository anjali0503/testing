export class Login{
    loginId:number=0;
    userId:string="";
    password:string="";
    designation="";
}

