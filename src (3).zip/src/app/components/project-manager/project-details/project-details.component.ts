import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectDetails } from 'src/app/domain/project';
import { ProjectDetailsService } from 'src/app/services/project-details.service';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {
projectDetails:ProjectDetails = new ProjectDetails();
allproject:ProjectDetails[]=[];
projectId:number=0;




  constructor(private projectService:ProjectDetailsService,
    private router:Router,
    private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    console.log("in projectDeatilsComponent");
    this.reloadData();
    this.projectId= this.activatedRoute.snapshot.params['projectId'];
    
   
    
  }

  reloadData(){
    this.projectService.getProject(this.projectId).subscribe(
      data=>{
        this.allproject=data;
        console.log(this.allproject);
        
      }
    );
  }

}
