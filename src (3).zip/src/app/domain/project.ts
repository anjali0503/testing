
export class ProjectDetails{
    projectId:string="";
    projectName:string="";
    projectCost:number=0
}






	  
	