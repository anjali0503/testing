import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviwer-home',
  templateUrl: './interviwer-home.component.html',
  styleUrls: ['./interviwer-home.component.css']
})
export class InterviwerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
