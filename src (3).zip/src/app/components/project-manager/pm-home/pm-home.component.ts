import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pm-home',
  templateUrl: './pm-home.component.html',
  styleUrls: ['./pm-home.component.css']
})
export class PmHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
