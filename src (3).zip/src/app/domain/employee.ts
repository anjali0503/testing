import { ProjectDetails } from "./project";

export class EmployeeDetails{
    employeeId:number=0;
    ename :string="";
    salary:number=0;
   projectDetails:ProjectDetails=new ProjectDetails();
   designation:string="";
    LoginId:number=0;
    mgr:number=0;
    skill1:string="";
    skill2:string="";
    skill3:string="";
    status:string="";
    
}











