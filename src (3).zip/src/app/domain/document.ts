
export class DocumentDetails{
    documentId:number=0;
    documentType:string="";
    documentFormate:string="";
}







// private byte[] documentFile;